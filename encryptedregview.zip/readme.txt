


EncryptedRegView v1.03
Copyright (c) 2016 - 2017 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

EncryptedRegView is a tool for Windows that scans the Registry of your
current running system or the Registry of external hard drive you choose
and searches for data encrypted with DPAPI (Data Protection API). When it
finds encrypted data in the Registry, it tries to decrypt it and displays
the decrypted data in the main window of EncryptedRegView. With this
tool, you may find passwords and other secret data stored in the Registry
by Microsoft products as well as by 3-party products.



System Requirements
===================

This utility works on any version of Windows, starting from Windows XP
and up to Windows 10. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.03:
  o Fixed another bug of skipping Registry keys when scanning files
    on external drive.

* Version 1.02:
  o Fixed bug: EncryptedRegView skipped some of the Registry key
    under HKEY_CURRENT_USER\Software\Classes when scanning files on
    external drive.

* Version 1.01:
  o Fixed the lower pane to switch focus when pressing tab key.

* Version 1.00 - First release.



Start Using EncryptedRegView
============================

EncryptedRegView doesn't require any installation process or additional
DLL files. In order to start using it, simply run the executable file -
EncryptedRegView.exe

After running it, the 'Advanced Options' window is opened and allows you
to choose the settings of the Registry scan. By default, EncryptedRegView
offers you to scan the Registry of your current running system and
current user, without elevation (Run As Administrator). If you check the
'Run as administrator to decrypt system protected data' option,
EncryptedRegView will be executed as Administrator (elevation) and then
it might be able to decrypt system protected data that cannot be
decrypted with normal user privilege.

After pressing the 'OK' button, EncryptedRegView starts to scan the
Registry and searches for DPAPI-encrypted data. When it finds encrypted
data, it tries to decrypt it. If EncryptedRegView successfully decrypts
the data, a new item is added to the upper pane with 'Succeeded' in the
'Decryption Result' column and green icon. You can look at the entire
decrypted information as Hex-Dump format in the lower pane by selecting
the desired item in the upper pane. If the decrypted information is a
string, it's also displayed in the upper pane under the 'Decrypted Value'
column.
If the decryption process fails, a new item is added to the upper pane
with 'Failed' in the 'Decryption Result' column and red icon.



Scanning Registry In External Hard Drive
========================================

EncryptedRegView also allows you to scan the Registry of external hard
drive plugged to your computer. In order to easily scan the Registry in
external hard drive, choose the 'Scan the Registry of external drive'
option in the top combo-box and then choose or type the path of the
external drive and click the 'Automatic Fill' button. EncryptedRegView
automatically fills for you the correct folders on the external drive
(Registry Hives Folder, User registry file, User classes registry file,
Protect Folders). Be aware that EncryptedRegView chooses the user profile
(c:\users\[Profile Name]) with the latest modified time, so you may need
to manually replace the paths if you want to scan another user profile.
Also, in order to decrypt user-encrypted data on external drive (usually
stored under HKEY_CURRENT_USER key), you must provide the correct logon
password of the user. In order to decrypt system-encrypted data on
external drive (usually stored under HKEY_LOCAL_MACHINE key), there is no
need for the logon password in order to decrypt the data.



Failure Reasons
===============

EncryptedRegView may fail to decrypt DPAPI data due to one of the
following reasons:
* The DPAPI data is encrypted with additional key/password. For
  example: Internet Explorer stores passwords under
  HKEY_CURRENT_USER\Software\Microsoft\Internet
  Explorer\IntelliForms\Storage2 key and the passwords are encrypted with
  the URL of the Web page, so EncryptedRegView fails to decrypt these
  encrypted values.
* EncryptedRegView cannot decrypt the data because it needs to access
  system keys. You can solve this issue by running EncryptedRegView as
  Administrator.
* The provided user logon password is incorrect (Relevant only for
  external drive scanning)
* Encryption keys are missing (Stored in the 'Protect' folders)



Columns Description
===================


* Registry Key Path: The full path of the Registry key.
* Value Name: The name of the Registry value where the DPAPI encrypted
  data was found.
* Decryption Result: Result of the decryption - Succeeded or Failed.
* Decrypted Value: If the decrypted data contains a simple string then
  it's displayed in this column. The entire decrypted data is displayed
  in the lower pane.
* Encrypted Data Length: Total length of the encrypted data.
* Decrypted Data Length: Total length of the decrypted data.
* Hash Algorithm: Hash algorithm used in the DPAPI encrypted data. In
  Windows 7 and later it's usually SHA512.
* Encryption Algorithm: Encryption algorithm used in the DPAPI
  encrypted data. In Windows 7 and later it's usually AES256.
* Name: The name of the DPAPI encrypted data block.
* Key File: Name of the key file that was used to encrypt the data. The
  key file is located in a 'Protect' folder (e.g:
  C:\Users\admin\AppData\Roaming\Microsoft\Protect )



Translating EncryptedRegView to other languages
===============================================

In order to translate EncryptedRegView to other language, follow the
instructions below:
1. Run EncryptedRegView with /savelangfile parameter:
   EncryptedRegView.exe /savelangfile
   A file named EncryptedRegView_lng.ini will be created in the folder of
   EncryptedRegView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run EncryptedRegView, and all
   translated strings will be loaded from the language file.
   If you want to run EncryptedRegView without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this and you don't
sell it or distribute it as a part of commercial product. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
