


DataProtectionDecryptor v1.06
Copyright (c) 2017 - 2018 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

DataProtectionDecryptor is a powerful tool for Windows that allows you to
decrypt passwords and other information encrypted by the DPAPI (Data
Protection API) system of Windows operating system. You can use this tool
to decrypt DPAPI data on your current running system and to decrypt DPAPI
data stored on external hard drive.



About DPAPI
===========

DPAPI is a decryption/encryption system used by Microsoft products as
well as by 3-party products to decrypt and encrypt passwords and other
secret information on Windows operating system. DPAPI decrypted data
always begins with the following sequence of bytes, so you can easily
detect it:
01 00 00 00 D0 8C 9D DF 01 15 D1 11 8C 7A 00 C0 4F C2 97 EB

Here's some examples for passwords and other data encrypted with DPAPI:
* Passwords of Microsoft Outlook accounts, stored in the Registry under
  HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Windows
  Messaging Subsystem\Profiles or
  HKEY_CURRENT_USER\Software\Microsoft\Office\15.0\Outlook\Profiles or
  HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Outlook\Profiles
  (Depending on version of Outlook)
* Credentials files of Windows (e.g: C:\Users\[User
  Profile]\AppData\Roaming\Microsoft\Credentials , C:\Users\[User
  Profile]\AppData\Local\Microsoft\Credentials )
* Wireless network keys (Stored inside XML files under
  C:\ProgramData\Microsoft\Wlansvc\Profiles\Interfaces )
* Passwords in some versions of Internet Explorer, stored in the
  following Registry key: HKEY_CURRENT_USER\Software\Microsoft\Internet
  Explorer\IntelliForms\Storage2
* Passwords stored in the passwords file of Chrome Web browser ('Login
  Data' file in the profile of Chrome).
* Encrypted cookies in Chrome Web browser ('Cookies' file in the
  profile of Chrome)



System Requirements
===================

This tool works on any version of Windows, starting from Windows XP and
up to Windows 10. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.06:
  o Fixed the lower pane to use the appropriate font size in high DPI
    mode.

* Version 1.05:
  o Added 'Display Encrypted Data In Lower Pane' option.

* Version 1.00 - First release.



Decryption Modes
================

You can use this tool to decrypt DPAPI-encrypted data in 2 different
modes:
* Decrypt data of the current system and user - In this mode you don't
  need to provide the logon password of the user or any other
  information, but you may need to run DataProtectionDecryptor as
  administrator.
* Decrypt data of another system or another user on your current system
  - In this mode you have to provide the path of Registry files and the
  Protect folders of Windows, and you may also need to provide the logon
  password of the user if the password was used to decrypt the data.



Using DataProtectionDecryptor
=============================

After you run DataProtectionDecryptor.exe, the 'DPAPI Decryption Options'
window is displayed. You can also open this window by pressing F9.
Here's the instructions for using the 'DPAPI Decryption Options' window:
* Choose the 'Decryption Mode'. If the DPAPI data was encrypted on your
  own computer with your current user, choose the 'Decrypt DPAPI data
  from current system and current user' option. If you want to decrypt
  DPAPI data created on another system stored on external drive, choose
  the 'Decrypt DPAPI data from external drive or another user' option.
* If you selected the external drive decryption mode: Choose the root
  folder of your external drive, click the 'Automatic Fill' button and
  the other fields (Protect Folders, Registry Hives Folder) will be
  filled for you. You can also manually fill these fields with the
  correct folders. If the DPAPI data was encrypted with the logon
  password, you have to enter this password in the 'Windows Login
  Password' field.
* In the DPAPI data section, you can choose one of the following
  options:
  o Decrypt DPAPI data stored in the specified file or files: If you
    choose this option, you can specify any file that contains the DPAPI
    encrypted data as binary data or as text. Examples for files that you
    can specify: Windows Registry hives (ntuser.dat, SOFTWARE file in
    C:\windows\system32\config), .reg files exported from the Registry,
    Windows Credentials files, Wireless network key files (stored in
    C:\ProgramData\Microsoft\Wlansvc\Profiles\Interfaces ), cookies and
    passwords file of Chrome Web browser.
  o Decrypt DPAPI data from the specified string: If you choose this
    option, you should type or paste the sequence of DPAPI bytes in the
    DPAPI data text-box. For example:
    01 00 00 00 D0 8C 9D DF 01 15 D1 11 8C 7A 00 C0 4F C2 97 EB....
    01,00,00,00,D0,8C,9D,DF,01,15,D1,11,8C,7A,00,C0,4F,C2,97,EB...
    01000000D08C9DDF0115D1118C7A00C04FC297EB...
    You can also paste the text from .reg file of Windows that contains
    the DPAPI encrypted data.

* Optional Entropy: You should use this option only if the DPAPI data
  is encrypted with additional key. You can specify the key in
  hexadecimal format (e.g: 2A 3D B8 C9...) , as ANSI string or as Unicode
  string.

After filling all needed fields in the 'DPAPI Decryption Options' window,
press the 'Ok' button and DataProtectionDecryptor will start decrypting
the DPAPI and display the result on the main window.



The Main Window
===============

The main window displays the result of the DPAPI decryption. In the upper
pane table, a new line is added for every DPAPI data block. When
selecting an item in the upper pane, the lower pane displays the
decrypted data in hex-dump format.



Upper Pane Columns Description
==============================


* Decryption Result: Result of the decryption process (Succeeded or
  Failed).
* Decrypted Size: Size of the decrypted data block (bytes).
* Encrypted Size: Size of the encrypted data block (bytes).
* Description: Description stored inside the DPAPI data block (might be
  empty)
* Hash Algorithm: Hash algorithm that was used in the encryption
  process of the DPAPI block (SHA1 or SHA512).
* Crypt Algorithm: Crypt algorithm that was used in the encryption
  process of the DPAPI block (3DES or AES256).
* Key Encrypted With: Specifies whether the key file is encrypted with
  a system key (Stored in the Registry) or with the user SID+password.
* Key File Guid: Specifies the Guid of the key file that was used for
  encryption.
* Key File Hash Algorithm: Hash algorithm that was used in the
  encryption process of the key file.
* Key File Crypt Algorithm: Crypt algorithm that was used in the
  encryption process of the key file.
* Key Filename: Specifies the key filename that was used for encryption
  (Located in the 'Protect' folder).
* Data Filename: Specifies the filename that contain the DPAPI
  encrypted data.



What to do when DPAPI decryption fails...
=========================================


* If you try to decrypt DPAPI data on your current running system, try
  to run DataProtectionDecryptor as administrator by pressing Ctrl+F11.
  If the decryption still fails, you can also try to turn on the
  following option: 'Try to decrypt the data by executing code inside
  lsass.exe process (Requires elevation)'. For using this option on
  64-bit systems, you must use the 64-bit version of
  DataProtectionDecryptor.
* If you try to decrypt DPAPI data on external drive:
  o Verify that all folders specified in the 'DPAPI Decryption
    Options' window are correct and you have read permission for these
    folders.
  o if the 'Key Encrypted With' value is 'User SID+Login Password',
    verify that you type the correct login password of the user on the
    external system.




Translating DataProtectionDecryptor to other languages
======================================================

In order to translate DataProtectionDecryptor to other language, follow
the instructions below:
1. Run DataProtectionDecryptor with /savelangfile parameter:
   DataProtectionDecryptor.exe /savelangfile
   A file named DataProtectionDecryptor_lng.ini will be created in the
   folder of DataProtectionDecryptor utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run DataProtectionDecryptor, and
   all translated strings will be loaded from the language file.
   If you want to run DataProtectionDecryptor without the translation,
   simply rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this and you don't
sell it or distribute it as a part of commercial product. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
